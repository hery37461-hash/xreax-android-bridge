#!/usr/bin/env python3
"""XREAX / TREX / JARVIS Termux bridge.

A small, local-only HTTP bridge for an Android app running on the same device.
It accepts requests only for explicitly configured scripts under $HOME and never
passes API input to a shell. Each registered script receives one JSON object on
stdin and may write JSON (preferred) or plain text to stdout.

Run: python ~/xreax_termux_bridge.py
Config: ~/.xreax_bridge/config.json
"""

from __future__ import annotations

import hmac
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit

APP_DIR = Path.home() / ".xreax_bridge"
CONFIG_PATH = APP_DIR / "config.json"
ROBOT_IDS = ("xreax", "trex", "jarvis")
MAX_REQUEST_BYTES = 64 * 1024
MAX_RESPONSE_CHARS = 24_000
DEFAULT_TIMEOUT_SECONDS = 60

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
LOG = logging.getLogger("xreax-bridge")
_RUNNING: set[str] = set()
_RUNNING_LOCK = threading.Lock()


def default_config() -> dict[str, Any]:
    return {
        "host": "127.0.0.1",
        "port": 8765,
        "token": secrets.token_urlsafe(32),
        "max_execution_seconds": DEFAULT_TIMEOUT_SECONDS,
        "robots": {
            "xreax": {
                "name": "XREAX",
                "enabled": False,
                "script": "",
                "interpreter": "python",
            },
            "trex": {
                "name": "TREX",
                "enabled": False,
                "script": "",
                "interpreter": "python",
            },
            "jarvis": {
                "name": "JARVIS",
                "enabled": False,
                "script": "",
                "interpreter": "python",
            },
        },
    }


def write_config(config: dict[str, Any]) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(APP_DIR, 0o700)
    except OSError:
        pass
    tmp_path = CONFIG_PATH.with_suffix(".json.tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
        f.write("\n")
    try:
        os.chmod(tmp_path, 0o600)
    except OSError:
        pass
    tmp_path.replace(CONFIG_PATH)
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass


def load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        config = default_config()
        write_config(config)
        print("\nKonfigurasi bridge baru dibuat:", CONFIG_PATH)
        print("Token aplikasi (simpan privat, masukkan ke pengaturan koneksi aplikasi):")
        print(config["token"])
        print("\nEdit konfigurasi dan daftarkan skrip sebelum digunakan.")
        print("Contoh: nano ~/.xreax_bridge/config.json\n")
        return config

    try:
        with CONFIG_PATH.open("r", encoding="utf-8") as f:
            config = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Tidak dapat membaca {CONFIG_PATH}: {exc}") from exc

    if not isinstance(config, dict):
        raise RuntimeError("Isi konfigurasi harus berupa objek JSON.")
    config.setdefault("host", "127.0.0.1")
    config.setdefault("port", 8765)
    config.setdefault("max_execution_seconds", DEFAULT_TIMEOUT_SECONDS)
    if not isinstance(config.get("token"), str) or len(config["token"]) < 24:
        raise RuntimeError("Token konfigurasi tidak ada atau terlalu pendek (minimal 24 karakter).")
    if config["host"] != "127.0.0.1":
        raise RuntimeError("Demi keamanan, host bridge harus tetap 127.0.0.1 (loopback perangkat).")
    try:
        port = int(config["port"])
        timeout = int(config["max_execution_seconds"])
    except (TypeError, ValueError) as exc:
        raise RuntimeError("Nilai port dan max_execution_seconds harus berupa angka.") from exc
    if not 1024 <= port <= 65535:
        raise RuntimeError("Port harus berada pada rentang 1024 sampai 65535.")
    if not 1 <= timeout <= 300:
        raise RuntimeError("max_execution_seconds harus berada pada rentang 1 sampai 300.")
    if not isinstance(config.get("robots"), dict):
        raise RuntimeError("Bagian robots harus berupa objek JSON.")

    for robot_id in ROBOT_IDS:
        robot = config["robots"].setdefault(robot_id, {})
        robot.setdefault("name", robot_id.upper())
        robot.setdefault("enabled", False)
        robot.setdefault("script", "")
        robot.setdefault("interpreter", "python")
    return config


def resolve_script(robot: dict[str, Any]) -> Path | None:
    if not robot.get("enabled"):
        return None
    configured = robot.get("script")
    if not isinstance(configured, str) or not configured.strip():
        return None
    candidate = Path(configured).expanduser()
    if not candidate.is_absolute():
        candidate = Path.home() / candidate
    try:
        resolved = candidate.resolve(strict=True)
        home = Path.home().resolve(strict=True)
        if os.path.commonpath((str(home), str(resolved))) != str(home):
            LOG.warning("Skrip ditolak karena berada di luar direktori Home Termux.")
            return None
        if not resolved.is_file():
            return None
        return resolved
    except (OSError, ValueError):
        return None


def robot_status(config: dict[str, Any], robot_id: str) -> dict[str, Any]:
    robot = config["robots"].get(robot_id, {})
    script_path = resolve_script(robot)
    with _RUNNING_LOCK:
        is_running = robot_id in _RUNNING
    ready = script_path is not None
    return {
        "id": robot_id,
        "name": str(robot.get("name", robot_id.upper())),
        "online": ready,
        "ready": ready,
        "running": is_running,
        "message": "Skrip siap" if ready else "Skrip belum didaftarkan atau tidak ditemukan",
    }


def json_bytes(payload: Any) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "XREAX-Termux-Bridge/1.0"
    sys_version = ""

    @property
    def config(self) -> dict[str, Any]:
        return self.server.bridge_config  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        LOG.info("%s - %s", self.client_address[0], fmt % args)

    def _send_json(self, status: int, payload: Any) -> None:
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        header = self.headers.get("Authorization", "")
        scheme, _, supplied = header.partition(" ")
        expected = self.config["token"]
        ok = scheme.lower() == "bearer" and bool(supplied)
        if ok:
            ok = hmac.compare_digest(supplied.strip(), expected)
        if not ok:
            self._send_json(401, {"ok": False, "error": "unauthorized"})
        return ok

    def _read_json_body(self) -> dict[str, Any] | None:
        raw_length = self.headers.get("Content-Length")
        try:
            length = int(raw_length or "0")
        except ValueError:
            self._send_json(400, {"ok": False, "error": "invalid_content_length"})
            return None
        if length < 0 or length > MAX_REQUEST_BYTES:
            self._send_json(413, {"ok": False, "error": "request_too_large"})
            return None
        try:
            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._send_json(400, {"ok": False, "error": "invalid_json"})
            return None
        if not isinstance(payload, dict):
            self._send_json(400, {"ok": False, "error": "json_object_required"})
            return None
        return payload

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if not self._authorized():
            return
        path = unquote(urlsplit(self.path).path)
        if path not in ("/health", "/api/v1/status"):
            self._send_json(404, {"ok": False, "error": "not_found"})
            return
        self._send_json(
            200,
            {
                "ok": True,
                "bridge": "online",
                "termux": "online",
                "timestamp": int(time.time()),
                "robots": [robot_status(self.config, robot_id) for robot_id in ROBOT_IDS],
            },
        )

    def do_POST(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if not self._authorized():
            return
        path = unquote(urlsplit(self.path).path)
        match = re.fullmatch(r"/api/v1/robots/(xreax|trex|jarvis)/run", path)
        if not match:
            self._send_json(404, {"ok": False, "error": "not_found"})
            return
        robot_id = match.group(1)
        payload = self._read_json_body()
        if payload is None:
            return
        script_input = payload.get("input", {})
        if not isinstance(script_input, dict):
            self._send_json(400, {"ok": False, "error": "input_must_be_json_object"})
            return

        robot = self.config["robots"].get(robot_id, {})
        script_path = resolve_script(robot)
        if script_path is None:
            self._send_json(409, {"ok": False, "error": "script_not_configured", "robot": robot_id})
            return
        interpreter = str(robot.get("interpreter", "python")).lower()
        if interpreter == "python":
            command = [sys.executable, str(script_path)]
        elif interpreter == "bash":
            bash = shutil.which("bash")
            if not bash:
                self._send_json(500, {"ok": False, "error": "bash_not_found"})
                return
            command = [bash, str(script_path)]
        elif interpreter == "direct":
            if not os.access(script_path, os.X_OK):
                self._send_json(409, {"ok": False, "error": "script_not_executable"})
                return
            command = [str(script_path)]
        else:
            self._send_json(500, {"ok": False, "error": "unsupported_interpreter"})
            return

        with _RUNNING_LOCK:
            if robot_id in _RUNNING:
                self._send_json(409, {"ok": False, "error": "robot_busy", "robot": robot_id})
                return
            _RUNNING.add(robot_id)

        timeout = int(self.config["max_execution_seconds"])
        LOG.info("Menjalankan skrip terdaftar untuk %s", robot_id.upper())
        try:
            completed = subprocess.run(
                command,
                input=json.dumps(script_input, ensure_ascii=False),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                cwd=str(Path.home()),
                shell=False,
                check=False,
            )
            stdout = completed.stdout[-MAX_RESPONSE_CHARS:]
            stderr = completed.stderr[-MAX_RESPONSE_CHARS:]
            result: Any = None
            if stdout.strip():
                try:
                    result = json.loads(stdout)
                except json.JSONDecodeError:
                    result = {"text": stdout}
            self._send_json(
                200 if completed.returncode == 0 else 500,
                {
                    "ok": completed.returncode == 0,
                    "robot": robot_id,
                    "exit_code": completed.returncode,
                    "result": result,
                    "stdout": stdout,
                    "stderr": stderr,
                    "timestamp": int(time.time()),
                },
            )
        except subprocess.TimeoutExpired as exc:
            out = exc.stdout or ""
            err = exc.stderr or ""
            if isinstance(out, bytes):
                out = out.decode("utf-8", errors="replace")
            if isinstance(err, bytes):
                err = err.decode("utf-8", errors="replace")
            self._send_json(
                504,
                {
                    "ok": False,
                    "robot": robot_id,
                    "error": "script_timeout",
                    "timeout_seconds": timeout,
                    "stdout": str(out)[-MAX_RESPONSE_CHARS:],
                    "stderr": str(err)[-MAX_RESPONSE_CHARS:],
                },
            )
        except OSError as exc:
            LOG.exception("Gagal menjalankan skrip robot %s", robot_id)
            self._send_json(500, {"ok": False, "robot": robot_id, "error": "script_launch_failed", "detail": str(exc)})
        finally:
            with _RUNNING_LOCK:
                _RUNNING.discard(robot_id)


def main() -> int:
    try:
        config = load_config()
    except RuntimeError as exc:
        LOG.error("%s", exc)
        return 2

    server = ThreadingHTTPServer((config["host"], int(config["port"])), BridgeHandler)
    server.daemon_threads = True
    server.bridge_config = config  # type: ignore[attr-defined]
    LOG.info("Bridge berjalan pada http://%s:%s", config["host"], config["port"])
    LOG.info("Endpoint status: GET /api/v1/status")
    LOG.info("Robot: POST /api/v1/robots/{xreax|trex|jarvis}/run")
    LOG.info("Hentikan dengan Ctrl+C. Bridge hanya menerima koneksi dari perangkat ini.")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        LOG.info("Bridge dihentikan oleh pengguna.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

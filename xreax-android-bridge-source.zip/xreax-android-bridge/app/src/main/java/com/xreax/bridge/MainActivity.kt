package com.xreax.bridge

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

/** A small connector demo. It is not yet the floating-overlay/animated robot UI. */
class MainActivity : Activity() {
    private lateinit var bridgeClient: TermuxBridgeClient
    private lateinit var urlInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var promptInput: EditText
    private lateinit var statusText: TextView
    private lateinit var resultText: TextView

    private val background = Color.rgb(7, 16, 37)
    private val panel = Color.rgb(16, 32, 61)
    private val cyan = Color.rgb(0, 213, 255)
    private val white = Color.rgb(235, 244, 255)
    private val muted = Color.rgb(150, 169, 197)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridgeClient = TermuxBridgeClient()
        window.statusBarColor = background
        window.navigationBarColor = background
        window.decorView.setBackgroundColor(background)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
        }

        content.addView(label("XREAX • TERMUX BRIDGE", 24f, white, bold = true))
        content.addView(label("Konektor lokal untuk tiga robot", 14f, muted))
        content.addView(space(18))

        urlInput = editField("Alamat bridge", "http://127.0.0.1:8765").also { content.addView(it) }
        tokenInput = editField("Token bridge (dari Termux)", "").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }.also { content.addView(it) }
        content.addView(space(8))

        content.addView(actionButton("Periksa koneksi / status") {
            withCredentials { baseUrl, token ->
                setBusy("Memeriksa Termux…")
                bridgeClient.getStatus(baseUrl, token, callback = { response, error ->
                    if (error != null) {
                        showStatus("Gagal terhubung: ${error.message ?: "periksa Termux dan token"}")
                    } else if (response != null) {
                        val robots = response.optJSONArray("robots")
                        val lines = mutableListOf<String>()
                        lines += "Termux: ${response.optString("termux", "unknown").uppercase()}"
                        if (robots != null) {
                            for (index in 0 until robots.length()) {
                                val robot = robots.optJSONObject(index) ?: continue
                                val online = robot.optBoolean("online", false)
                                val state = if (online) "ONLINE" else "OFFLINE"
                                lines += "${robot.optString("name")}: $state — ${robot.optString("message", "")}" 
                            }
                        }
                        showStatus(lines.joinToString("\n"))
                    }
                })
            }
        })
        content.addView(space(16))

        content.addView(label("Pesan untuk skrip", 15f, white, bold = true))
        promptInput = editField("Contoh: ringkas status mesin…", "").apply {
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }.also { content.addView(it) }
        content.addView(label("Teks ini dikirim sebagai JSON input ke skrip terdaftar; bukan perintah shell bebas.", 12f, muted))
        content.addView(space(8))

        content.addView(robotButton("Jalankan XREAX", "xreax"))
        content.addView(robotButton("Jalankan TREX", "trex"))
        content.addView(robotButton("Jalankan JARVIS", "jarvis"))
        content.addView(space(12))
        content.addView(label("Status", 15f, white, bold = true))
        statusText = label("Belum diperiksa", 14f, muted).also { content.addView(it) }
        content.addView(space(10))
        content.addView(label("Hasil terakhir", 15f, white, bold = true))
        resultText = label("Belum ada hasil", 14f, muted).also { content.addView(it) }

        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    private fun robotButton(title: String, robotId: String): Button = actionButton(title) {
        withCredentials { baseUrl, token ->
            val userText = promptInput.text.toString().trim()
            val input = JSONObject().put("text", userText)
            setBusy("Mengirim ke $title…")
            bridgeClient.runRobot(baseUrl, token, robotId, input, callback = { response, error ->
                if (error != null) {
                    showStatus("Gagal menjalankan $title: ${error.message ?: "kesalahan tidak diketahui"}")
                } else if (response != null) {
                    val output = response.optJSONObject("result")?.optString("text")
                        ?.takeIf { it.isNotBlank() }
                        ?: response.optString("stdout", "").ifBlank { response.toString(2) }
                    showResult("$title selesai (exit ${response.optInt("exit_code", 0)}):\n$output")
                    showStatus("Bridge Termux online • ${title.removePrefix("Jalankan ")} siap")
                }
            })
        }
    }

    private fun withCredentials(action: (String, String) -> Unit) {
        val baseUrl = urlInput.text.toString().trim()
        val token = tokenInput.text.toString().trim()
        if (token.isBlank()) {
            showStatus("Masukkan token dari ~/.xreax_bridge/config.json")
            return
        }
        action(baseUrl, token)
    }

    private fun setBusy(message: String) {
        statusText.text = message
        statusText.setTextColor(cyan)
    }

    private fun showStatus(message: String) = runOnUiThread {
        statusText.text = message
        statusText.setTextColor(if (message.contains("OFFLINE", ignoreCase = true) || message.contains("Gagal", true)) Color.rgb(255, 132, 132) else cyan)
    }

    private fun showResult(message: String) = runOnUiThread {
        resultText.text = message
        resultText.setTextColor(white)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }

    private fun editField(hint: String, initial: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(initial)
        setTextColor(white)
        setHintTextColor(muted)
        textSize = 14f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(8)
        }
    }

    private fun actionButton(title: String, action: () -> Unit): Button = Button(this).apply {
        text = title
        setTextColor(background)
        setBackgroundColor(cyan)
        isAllCaps = false
        textSize = 15f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(8)
        }
    }

    private fun space(heightDp: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(heightDp))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        bridgeClient.close()
        super.onDestroy()
    }
}

# XREAX Bridge — Android Kotlin connector demo

A minimal native Android app that connects to the Python bridge at `127.0.0.1:8765`, checks Termux/robot status, and sends JSON input to the registered XREAX, TREX, or JARVIS script.

## What this source does

- GET `http://127.0.0.1:8765/api/v1/status`
- POST `http://127.0.0.1:8765/api/v1/robots/{xreax|trex|jarvis}/run`
- Adds the configured bearer token to every request.
- Restricts destination hosts to `127.0.0.1` or `localhost` so the bearer token is not sent to a remote host.
- Sends the text field as JSON input (`{"input":{"text":"..."}}`), not as a shell command.
- Displays Termux offline / HTTP / authorization errors.

This is a **connector demo**, not the finished XREAX product. It does not yet implement floating overlay windows, three animated robot characters, voice input/output, dashboards per robot, custom dashboard editing, accessibility automation, or WhatsApp actions. Those features need separate Android services, permissions, and UI work. No APK was built by this source handoff.

## Requirements

- Android Studio with Android SDK Platform 35 installed.
- Android device with Termux and the Python bridge running on that same device.
- The bridge token from `~/.xreax_bridge/config.json`.

## Open and build

1. Open this folder in Android Studio (`File > Open`).
2. Let Gradle Sync download the Android Gradle and Kotlin plugins.
3. Connect the Android phone with USB debugging enabled, or create an emulator.
4. Select the `app` run configuration and press **Run**.
5. For an APK, choose **Build > Build APK(s)**. Android Studio reports the APK path when the build completes.

The source declares `minSdk 23` and `targetSdk 35`.

## Connect

1. On the phone, launch `python ~/xreax_termux_bridge.py` in Termux and leave it running.
2. Open the demo app. Keep the default bridge URL `http://127.0.0.1:8765`.
3. Paste the bearer token into the token field (it is not persisted by this demo).
4. Tap **Periksa koneksi / status**.
5. Register each script path and `enabled: true` in the Termux bridge JSON configuration. Tap the desired robot button to run its script.

Each registered script reads a JSON object from stdin. The demo sends `{"text":"your text"}` as that object. Return JSON or plain text to stdout. The native app sends no arbitrary shell command.

## Android cleartext note

The bridge uses plain HTTP only over device loopback because the Python server binds exclusively to `127.0.0.1`. The demo's client rejects remote hosts. `android:usesCleartextTraffic="true"` is present to allow this local HTTP request on modern Android; in a larger app, keep all bridge calls constrained to loopback and review any other code that could use cleartext HTTP.

## Source layout

- `app/src/main/java/com/xreax/bridge/TermuxBridgeClient.kt` — authenticated HTTP client.
- `app/src/main/java/com/xreax/bridge/MainActivity.kt` — minimal status/control demo.
- `app/src/main/AndroidManifest.xml` — launcher activity and network permission.

package com.xreax.bridge

import android.net.Uri
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** HTTP client for the XREAX Termux bridge. Network work runs off the UI thread. */
class TermuxBridgeClient : AutoCloseable {
    fun interface Callback {
        fun onComplete(response: JSONObject?, error: Exception?)
    }

    private val executor: ExecutorService = Executors.newFixedThreadPool(3)

    fun getStatus(baseUrl: String, token: String, callback: Callback) {
        submit(baseUrl, token, "GET", "/api/v1/status", null, callback, timeoutMs = 5_000)
    }

    fun runRobot(
        baseUrl: String,
        token: String,
        robotId: String,
        input: JSONObject,
        callback: Callback
    ) {
        val safeId = robotId.lowercase()
        if (safeId !in setOf("xreax", "trex", "jarvis")) {
            callback.onComplete(null, IllegalArgumentException("Robot ID tidak dikenal."))
            return
        }
        val body = JSONObject().put("input", input)
        submit(
            baseUrl,
            token,
            "POST",
            "/api/v1/robots/$safeId/run",
            body,
            callback,
            timeoutMs = 70_000
        )
    }

    private fun submit(
        baseUrl: String,
        token: String,
        method: String,
        path: String,
        body: JSONObject?,
        callback: Callback,
        timeoutMs: Int
    ) {
        if (token.isBlank()) {
            callback.onComplete(null, IllegalArgumentException("Token bridge belum diisi."))
            return
        }
        executor.execute {
            try {
                val response = request(baseUrl, token, method, path, body, timeoutMs)
                callback.onComplete(response, null)
            } catch (e: Exception) {
                callback.onComplete(null, e)
            }
        }
    }

    @Throws(IOException::class)
    private fun request(
        baseUrl: String,
        token: String,
        method: String,
        path: String,
        body: JSONObject?,
        timeoutMs: Int
    ): JSONObject {
        val normalizedBase = baseUrl.trim().trimEnd('/')
        val uri = Uri.parse(normalizedBase)
        val host = uri.host?.lowercase()
        if (uri.scheme != "http" || host !in setOf("127.0.0.1", "localhost")) {
            throw IOException("Alamat harus HTTP loopback perangkat, misalnya http://127.0.0.1:8765")
        }
        if (uri.userInfo != null || uri.query != null || uri.fragment != null) {
            throw IOException("Alamat bridge tidak boleh berisi kredensial, query, atau fragment.")
        }

        val connection = (URL(normalizedBase + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 4_000
            readTimeout = timeoutMs
            instanceFollowRedirects = false
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }

        try {
            if (body != null) {
                connection.outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                    writer.write(body.toString())
                }
            }
            val statusCode = connection.responseCode
            val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val response = try {
                JSONObject(responseText)
            } catch (e: Exception) {
                throw IOException("Bridge mengirim respons yang bukan JSON (HTTP $statusCode).", e)
            }
            if (statusCode !in 200..299) {
                val reason = response.optString("error", "HTTP $statusCode")
                throw IOException("Bridge menolak permintaan: $reason (HTTP $statusCode)")
            }
            return response
        } finally {
            connection.disconnect()
        }
    }

    override fun close() {
        executor.shutdownNow()
    }
}
